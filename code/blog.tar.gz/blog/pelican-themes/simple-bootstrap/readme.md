this is a simple bootstrap pelican theme based on bootstrap [Narrow jumbotron](http://getbootstrap.com/examples/jumbotron-narrow/) template

## Screenshot ##

![screenshot](screenshot.png)
