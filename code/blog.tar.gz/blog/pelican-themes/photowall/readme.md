# Photowall

A very basic theme for Pelican for a simple image wall front page.


# Contact

Twitter: @trawg


# Screenshot

![Screenshot of Photowall theme](photowall.jpg)
